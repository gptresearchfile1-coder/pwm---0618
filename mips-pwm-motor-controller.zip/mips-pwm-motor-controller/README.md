# MIPS PWM Motor Controller

A 5-stage pipelined MIPS CPU that drives a PWM motor signal through Memory-Mapped I/O: the CPU runs an assembly program which writes an 8-bit duty value to a PWM peripheral, producing a square wave whose duty cycle follows a ramp-up → hold → ramp-down → hold motor-speed profile.

---

## System block diagram

```
            ┌──────────────────────────── mips.v (top) ────────────────────────────┐
            │                                                                       │
 switches ──┼──────────────────────────────┐                                       │
   [7:0]    │                               ▼                                       │
            │  ┌─────────┐   pcF   ┌──────────────┐  aluoutM/we  ┌────────────────┐ │
            │  │  instr  │◄────────│   datapath   │─────────────►│  data_memory   │ │
            │  │  memory │ instrF  │  (5-stage    │  readdataM   │  + MMIO decode │ │
            │  │  (ROM)  │────────►│   pipeline)  │◄─────────────│ 0x90/0x98/0x9C │ │
            │  └─────────┘         └──────────────┘              └───────┬────────┘ │
            │                          ▲   ▲                  duty[7:0]  │  en      │
            │                  controller  hazard                       ▼          │
            │                  alu regfile                     ┌──────────────────┐│
            │                                                  │ pwm_controller   ││──► pwm_out
            │                                                  │ counter+compare  ││
            │                                                  └──────────────────┘│
            └───────────────────────────────────────────────────────────────────────┘
```

---

## MMIO address map

| Address  | Device     | Direction  | Notes                          |
|----------|------------|------------|--------------------------------|
| `0x0000+`| RAM        | read/write | Normal data memory             |
| `0x0090` | switches   | read-only  | 8-bit external input           |
| `0x0098` | PWM duty   | write-only | 8-bit duty cycle (0–255)       |
| `0x009C` | PWM enable | write-only | 1-bit on/off                   |

Ordinary `lw`/`sw` instructions reach the peripherals — `data_memory.v` decodes the address in a `case` statement and routes special addresses to peripheral registers.

---

## How to build and run

You need **Icarus Verilog** (`iverilog` + `vvp`) and **GTKWave**.

```sh
make          # compile every .v file and run the simulation (writes wave.vcd)
make wave     # open wave.vcd in GTKWave
make asm      # (optional) regenerate memfile.dat from assemble.py
make clean    # remove build artefacts
```

Equivalent manual commands:

```sh
iverilog -g2012 -o sim.out -s mips_tb *.v
vvp sim.out
gtkwave wave.vcd
```

---

## What you'll see

When the simulation runs, the console prints each change of the duty register, e.g.:

```
t=     ... ns : duty =   0  (0%)   en=1
t=     ... ns : duty =   8  (3%)   en=1
...
t=     ... ns : duty = 255  (100%) en=1
...
```

In GTKWave, add these signals (under `mips_tb`):

* `duty_probe[7:0]`  — climbs 0 → 255, holds, falls 255 → 0, holds, then repeats (the **motor-speed profile**).
* `pwm_out`          — a square wave whose **high-time grows and shrinks with `duty_probe`** (period = 256 clock cycles).
* `counter_probe[7:0]` — the free-running 0→255 sawtooth inside the PWM block.
* `en_probe`         — goes high once, right after reset, and stays high.

The visual result is a triangle-shaped duty profile with `pwm_out` pulse-width tracking it. A reference rendering is in [`docs/waveform_profile.png`](docs/waveform_profile.png).

---

## File layout

```
mips_pwm_motor/
├── README.md            # this file (Document 1)
├── Makefile             # `make` builds & runs, `make wave` opens GTKWave
├── memfile.dat          # motor-control program in hex (loaded by mips.v)
├── mips.v               # top-level CPU: imem + datapath + dmem + pwm
├── mips_tb.v            # testbench: drives switches, monitors pwm_out
├── datapath.v           # 5-stage pipelined datapath (IF/ID/EX/MEM/WB)
├── controller.v         # control unit (main decoder + ALU decoder)
├── alu.v                # arithmetic-logic unit
├── regfile.v            # 32×32 register file
├── hazard.v             # forwarding + stall (hazard) unit
├── data_memory.v        # data memory + MMIO address decode
├── pwm_controller.v     # PWM peripheral (counter + comparator)
├── assemble.py          # helper: assembles the program + reference model
└── docs/
    ├── design_report.md      # Document 2
    ├── test_report.md        # Document 3
    └── waveform_profile.png  # reference render of the motor profile
```
