// ============================================================================
//  alu.v
//  Arithmetic-Logic Unit.
//
//  alucontrol encoding (4-bit):
//     0000 = AND
//     0001 = OR
//     0010 = ADD
//     0110 = SUB
//     0111 = SLT  (set-less-than, signed)
// ============================================================================
module alu (
    input  wire [31:0] a,
    input  wire [31:0] b,
    input  wire [3:0]  alucontrol,
    output reg  [31:0] result,
    output wire        zero
);

    wire [31:0] sub_ab = a - b;
    // signed set-less-than (handles overflow correctly)
    wire        slt    = (a[31] != b[31]) ? a[31] : sub_ab[31];

    always @(*) begin
        case (alucontrol)
            4'b0000: result = a & b;            // AND
            4'b0001: result = a | b;            // OR
            4'b0010: result = a + b;            // ADD
            4'b0110: result = sub_ab;           // SUB
            4'b0111: result = {31'b0, slt};     // SLT
            default: result = 32'b0;
        endcase
    end

    assign zero = (result == 32'b0);

endmodule
