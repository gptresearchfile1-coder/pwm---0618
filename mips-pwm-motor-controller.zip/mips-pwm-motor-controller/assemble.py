#!/usr/bin/env python3
"""
assemble.py  -- tiny MIPS assembler + reference model for the PWM PBL.

  * Assembles the Option-A motor-control program into memfile.dat (hex words).
  * Functionally simulates it (architectural, not cycle-accurate) so we can
    verify the duty-cycle profile and emit data for the waveform image.

This is a *development helper*. The graded hardware runs memfile.dat on the
Verilog CPU; this script just guarantees the hex is correct and documents the
expected behaviour.
"""

import sys, re

# ---------------------------------------------------------------- registers
REG = {'$zero':0,'$0':0,'$at':1,'$v0':2,'$v1':3,'$a0':4,'$a1':5,'$a2':6,'$a3':7,
       '$t0':8,'$t1':9,'$t2':10,'$t3':11,'$t4':12,'$t5':13,'$t6':14,'$t7':15,
       '$s0':16,'$s1':17,'$s2':18,'$s3':19,'$s4':20,'$s5':21,'$s6':22,'$s7':23,
       '$t8':24,'$t9':25,'$k0':26,'$k1':27,'$gp':28,'$sp':29,'$fp':30,'$ra':31}

R_FUNCT = {'add':0x20,'sub':0x22,'and':0x24,'or':0x25,'slt':0x2a}
I_OP    = {'addi':0x08,'andi':0x0c,'ori':0x0d,'slti':0x0a,'lw':0x23,'sw':0x2b,
           'beq':0x04,'bne':0x05}
J_OP    = {'j':0x02}

# ----------------------------------------------------------- the program
PROGRAM = r"""
        ori   $t0, $zero, 1          # t0 = 1
        sw    $t0, 0x9c($zero)       # enable PWM  (MMIO 0x9C <- 1)

main:
        ori   $t1, $zero, 0          # duty = 0

# ---------- ramp up : 0, 8, ..., 248 ----------
ramp_up:
        sw    $t1, 0x98($zero)       # MMIO 0x98 <- duty
        ori   $t3, $zero, 0          # delay counter
        ori   $t4, $zero, 100        # DELAY iterations
du_wait:
        addi  $t3, $t3, 1
        bne   $t3, $t4, du_wait
        addi  $t1, $t1, 8            # duty += 8
        slti  $t2, $t1, 256          # t2 = (duty < 256)
        bne   $t2, $zero, ramp_up

# ---------- hold at max (255) ----------
        ori   $t1, $zero, 255
        sw    $t1, 0x98($zero)
        ori   $t3, $zero, 0
        ori   $t4, $zero, 300        # HOLD iterations
hold_hi:
        addi  $t3, $t3, 1
        bne   $t3, $t4, hold_hi

# ---------- ramp down : 255, 247, ..., 7 ----------
        ori   $t1, $zero, 255
ramp_dn:
        sw    $t1, 0x98($zero)
        ori   $t3, $zero, 0
        ori   $t4, $zero, 100
dd_wait:
        addi  $t3, $t3, 1
        bne   $t3, $t4, dd_wait
        addi  $t1, $t1, -8           # duty -= 8
        slti  $t2, $t1, 0            # t2 = (duty < 0)
        beq   $t2, $zero, ramp_dn    # duty >= 0 -> keep ramping down

# ---------- hold at 0 ----------
        ori   $t1, $zero, 0
        sw    $t1, 0x98($zero)
        ori   $t3, $zero, 0
        ori   $t4, $zero, 300
hold_lo:
        addi  $t3, $t3, 1
        bne   $t3, $t4, hold_lo

        j     main
"""

# --------------------------------------------------------------- assembler
def clean(line):
    return line.split('#')[0].strip()

def parse_imm(tok):
    tok = tok.strip().rstrip(',')
    return int(tok, 16) if tok.lower().startswith('0x') or tok.lower().startswith('-0x') else int(tok)

def assemble(src):
    lines = [clean(l) for l in src.splitlines()]
    # pass 1: labels
    labels, idx = {}, 0
    toks_list = []
    for l in lines:
        if not l:
            continue
        if l.endswith(':'):
            labels[l[:-1]] = idx
            continue
        m = re.match(r'(\w+):\s*(.*)', l)
        if m and m.group(2) == '':
            labels[m.group(1)] = idx
            continue
        toks_list.append((idx, l))
        idx += 1
    # pass 2: encode
    words = []
    for idx, l in toks_list:
        parts = re.split(r'[ ,\t]+', l, maxsplit=1)
        op = parts[0]
        args = [a for a in re.split(r'[ ,\t]+', parts[1].strip())] if len(parts) > 1 else []
        if op in R_FUNCT:
            rd, rs, rt = REG[args[0]], REG[args[1]], REG[args[2]]
            w = (0 << 26)|(rs << 21)|(rt << 16)|(rd << 11)|(0 << 6)|R_FUNCT[op]
        elif op in I_OP and op in ('lw', 'sw'):
            rt = REG[args[0]]
            m = re.match(r'(-?(?:0x)?[0-9a-fA-F]+)\((\$\w+)\)', args[1])
            imm, rs = parse_imm(m.group(1)), REG[m.group(2)]
            w = (I_OP[op] << 26)|(rs << 21)|(rt << 16)|(imm & 0xffff)
        elif op in ('beq', 'bne'):
            rs, rt = REG[args[0]], REG[args[1]]
            off = labels[args[2]] - (idx + 1)
            w = (I_OP[op] << 26)|(rs << 21)|(rt << 16)|(off & 0xffff)
        elif op in I_OP:                      # addi/andi/ori/slti
            rt, rs, imm = REG[args[0]], REG[args[1]], parse_imm(args[2])
            w = (I_OP[op] << 26)|(rs << 21)|(rt << 16)|(imm & 0xffff)
        elif op in J_OP:
            w = (J_OP[op] << 26)|(labels[args[0]] & 0x3ffffff)
        else:
            raise ValueError(f"unknown op '{op}' in: {l}")
        words.append(w & 0xffffffff)
    return words, labels

# --------------------------------------------------- reference simulator
def simulate(words, max_cycles=60000):
    """Architectural sim, ~1 cycle/instruction. Returns trace of PWM state."""
    reg = [0]*32
    pc = 0
    duty, en, counter = 0, 0, 0
    trace = []      # (cycle, duty, en, pwm_out)
    duty_events = []  # (cycle, duty) at each sw to 0x98
    def s32(x): return x - (1 << 32) if x & 0x80000000 else x
    for cyc in range(max_cycles):
        if en:
            counter = (counter + 1) & 0xff
        pwm_out = 1 if (en and counter < duty) else 0
        trace.append((cyc, duty, en, pwm_out))
        if pc >> 2 >= len(words):
            break
        w = words[pc >> 2]
        op = (w >> 26) & 0x3f
        rs = (w >> 21) & 0x1f; rt = (w >> 16) & 0x1f; rd = (w >> 11) & 0x1f
        imm = w & 0xffff
        simm = imm - 0x10000 if imm & 0x8000 else imm
        nextpc = pc + 4
        if op == 0:                                  # R-type
            f = w & 0x3f
            a, b = s32(reg[rs]), s32(reg[rt])
            if   f == 0x20: reg[rd] = (a+b) & 0xffffffff
            elif f == 0x22: reg[rd] = (a-b) & 0xffffffff
            elif f == 0x24: reg[rd] = reg[rs] & reg[rt]
            elif f == 0x25: reg[rd] = reg[rs] | reg[rt]
            elif f == 0x2a: reg[rd] = 1 if a < b else 0
        elif op == 0x08: reg[rt] = (s32(reg[rs])+simm) & 0xffffffff   # addi
        elif op == 0x0c: reg[rt] = reg[rs] & imm                      # andi
        elif op == 0x0d: reg[rt] = reg[rs] | imm                      # ori
        elif op == 0x0a: reg[rt] = 1 if s32(reg[rs]) < simm else 0    # slti
        elif op == 0x23:                                              # lw
            addr = (reg[rs]+simm) & 0xffffffff
            reg[rt] = 0  # (no RAM reads in this program)
        elif op == 0x2b:                                             # sw
            addr = (reg[rs]+simm) & 0xffffffff
            if   addr == 0x98: duty = reg[rt] & 0xff; duty_events.append((cyc, duty))
            elif addr == 0x9c: en = reg[rt] & 1
        elif op == 0x04:                                            # beq
            if reg[rs] == reg[rt]: nextpc = pc + 4 + (simm << 2)
        elif op == 0x05:                                            # bne
            if reg[rs] != reg[rt]: nextpc = pc + 4 + (simm << 2)
        elif op == 0x02:                                            # j
            nextpc = (w & 0x3ffffff) << 2
        reg[0] = 0
        pc = nextpc & 0xffffffff
    return trace, duty_events

# --------------------------------------------------------------- main
if __name__ == '__main__':
    words, labels = assemble(PROGRAM)
    with open('memfile.dat', 'w') as f:
        for w in words:
            f.write(f"{w:08x}\n")
    print(f"[assemble] wrote {len(words)} instructions to memfile.dat")
    print(f"[assemble] labels: {labels}")

    trace, events = simulate(words)
    print(f"[simulate] simulated {len(trace)} cycles, {len(events)} duty writes")
    print("[simulate] first duty values written:",
          [d for _, d in events[:12]], "...")
    duties = [d for _, d in events]
    print(f"[simulate] duty min={min(duties)} max={max(duties)}")
    # save trace for plotting
    import json
    with open('trace.json', 'w') as f:
        json.dump({'trace': trace[:60000], 'events': events}, f)
    print("[simulate] trace saved to trace.json")
