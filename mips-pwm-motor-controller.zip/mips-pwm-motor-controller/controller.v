// ============================================================================
//  controller.v
//  Control unit = main decoder (opcode -> control word) + ALU decoder.
//
//  Supported instructions:
//     R-type : add sub and or slt   (funct decoded by aludec)
//     I-type : lw sw beq bne addi andi ori slti
//     J-type : j
//
//  NOTE on immediates: this design sign-extends every immediate. Our motor
//  program only uses small positive immediates with andi/ori, so sign- and
//  zero-extension coincide; this keeps the datapath simple. (Documented in
//  docs/design_report.md.)
// ============================================================================
module controller (
    input  wire [5:0] op,
    input  wire [5:0] funct,
    output reg        regwrite,
    output reg        regdst,
    output reg        alusrc,
    output reg        branch,    // beq or bne
    output reg        bne,       // 1 = bne, 0 = beq  (only meaningful if branch)
    output reg        memwrite,
    output reg        memtoreg,
    output reg        jump,
    output wire [3:0] alucontrol
);

    // ---- opcodes --------------------------------------------------------
    localparam OP_RTYPE = 6'b000000;
    localparam OP_LW    = 6'b100011;
    localparam OP_SW    = 6'b101011;
    localparam OP_BEQ   = 6'b000100;
    localparam OP_BNE   = 6'b000101;
    localparam OP_ADDI  = 6'b001000;
    localparam OP_ANDI  = 6'b001100;
    localparam OP_ORI   = 6'b001101;
    localparam OP_SLTI  = 6'b001010;
    localparam OP_J     = 6'b000010;

    reg [2:0] aluop;

    // ---- main decoder ---------------------------------------------------
    always @(*) begin
        // safe defaults (NOP-like)
        regwrite = 1'b0; regdst = 1'b0; alusrc = 1'b0;
        branch   = 1'b0; bne    = 1'b0;
        memwrite = 1'b0; memtoreg = 1'b0; jump = 1'b0;
        aluop    = 3'b000;
        case (op)
            OP_RTYPE: begin regwrite=1; regdst=1;            aluop=3'b010; end
            OP_LW   : begin regwrite=1; alusrc=1; memtoreg=1;aluop=3'b000; end
            OP_SW   : begin            alusrc=1; memwrite=1; aluop=3'b000; end
            OP_BEQ  : begin            branch=1;             aluop=3'b001; end
            OP_BNE  : begin            branch=1; bne=1;      aluop=3'b001; end
            OP_ADDI : begin regwrite=1; alusrc=1;            aluop=3'b000; end
            OP_ANDI : begin regwrite=1; alusrc=1;            aluop=3'b011; end
            OP_ORI  : begin regwrite=1; alusrc=1;            aluop=3'b100; end
            OP_SLTI : begin regwrite=1; alusrc=1;            aluop=3'b101; end
            OP_J    : begin jump=1; end
            default : ; // unknown -> NOP
        endcase
    end

    // ---- ALU decoder ----------------------------------------------------
    reg [3:0] aluctrl_r;
    always @(*) begin
        case (aluop)
            3'b000: aluctrl_r = 4'b0010;   // add
            3'b001: aluctrl_r = 4'b0110;   // sub
            3'b011: aluctrl_r = 4'b0000;   // and
            3'b100: aluctrl_r = 4'b0001;   // or
            3'b101: aluctrl_r = 4'b0111;   // slt
            default: begin                 // 3'b010 R-type: decode funct
                case (funct)
                    6'b100000: aluctrl_r = 4'b0010; // add
                    6'b100001: aluctrl_r = 4'b0010; // addu -> add
                    6'b100010: aluctrl_r = 4'b0110; // sub
                    6'b100011: aluctrl_r = 4'b0110; // subu -> sub
                    6'b100100: aluctrl_r = 4'b0000; // and
                    6'b100101: aluctrl_r = 4'b0001; // or
                    6'b101010: aluctrl_r = 4'b0111; // slt
                    default:   aluctrl_r = 4'b0010; // default add
                endcase
            end
        endcase
    end
    assign alucontrol = aluctrl_r;

endmodule
