// ============================================================================
//  data_memory.v
//  Unified data memory + Memory-Mapped I/O (MMIO) address decoder.
//
//  Address map (byte addresses, all word-aligned):
//     0x0000 .. 0x03FC : normal RAM        (read / write)
//     0x0090           : switches  (RO)    : 8-bit external input
//     0x0098           : PWM duty  (WO)    : 8-bit duty cycle  -> pwm_controller
//     0x009C           : PWM en    (WO)    : 1-bit enable      -> pwm_controller
//
//  Design rules from the spec:
//     * Writes are SYNCHRONOUS  (registered on the clock edge).
//     * Reads are COMBINATIONAL (so a lw gets its value in the same MEM stage).
// ============================================================================
module data_memory (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        we,          // memwrite (from MEM stage)
    input  wire [31:0] a,           // byte address (ALU result)
    input  wire [31:0] wd,          // write data (rt value)
    input  wire [7:0]  switches,    // external input pins
    output reg  [31:0] rd,          // read data -> WB stage
    // --- outputs that drive the PWM peripheral ---------------------------
    output reg  [7:0]  pwm_duty,
    output reg         pwm_en
);

    // 256 words of plain RAM (covers 0x000 .. 0x3FC).
    reg [31:0] RAM [0:255];

    // MMIO byte addresses
    localparam ADDR_SW   = 32'h0000_0090;  // switches  (read-only)
    localparam ADDR_DUTY = 32'h0000_0098;  // PWM duty  (write-only)
    localparam ADDR_EN   = 32'h0000_009C;  // PWM enable (write-only)

    integer i;

    // ---- synchronous write path + MMIO write decode ---------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pwm_duty <= 8'd0;
            pwm_en   <= 1'b0;
        end else if (we) begin
            case (a)
                ADDR_DUTY: pwm_duty <= wd[7:0];   // 0x98  -> PWM duty register
                ADDR_EN  : pwm_en   <= wd[0];     // 0x9C  -> PWM enable register
                ADDR_SW  : ;                      // 0x90 is read-only: ignore
                default  : RAM[a[9:2]] <= wd;     // ordinary RAM (word index)
            endcase
        end
    end

    // ---- combinational read path + MMIO read decode ---------------------
    always @(*) begin
        case (a)
            ADDR_SW  : rd = {24'b0, switches};    // 0x90 -> zero-extended switches
            ADDR_DUTY: rd = {24'b0, pwm_duty};    // readback (optional, harmless)
            ADDR_EN  : rd = {31'b0, pwm_en};      // readback (optional, harmless)
            default  : rd = RAM[a[9:2]];          // ordinary RAM
        endcase
    end

endmodule
