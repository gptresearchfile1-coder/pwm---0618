// ============================================================================
//  datapath.v
//  5-stage pipelined MIPS datapath (Harris & Harris style).
//
//  Stages:  IF | ID | EX | MEM | WB
//  Features:
//     * Early branch resolution in ID  (1-cycle branch penalty).
//     * Data forwarding from MEM/WB into the ALU inputs.
//     * Data forwarding from MEM into the ID-stage branch comparator.
//     * Load-use hazard: one-cycle stall (bubble) inserted automatically.
//     * Register file is read-after-write within one cycle (negedge write).
//
//  Instruction & data memories live in the top module (mips.v); this datapath
//  drives pcF / receives instrF, and drives aluoutM,writedataM,memwriteM /
//  receives readdataM.
// ============================================================================
module datapath (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [31:0] instrF,      // instruction fetched this cycle
    input  wire [31:0] readdataM,   // data read from data memory (MEM stage)
    output wire [31:0] pcF,         // program counter -> instruction memory
    output wire        memwriteM,   // store enable -> data memory
    output wire [31:0] aluoutM,     // address / ALU result -> data memory
    output wire [31:0] writedataM   // store data -> data memory
);

    // =====================================================================
    //  FETCH (IF)
    // =====================================================================
    reg  [31:0] pcF_r;
    wire [31:0] pcplus4F = pcF_r + 32'd4;
    wire [31:0] pcnextF;
    assign pcF = pcF_r;

    // =====================================================================
    //  pipeline registers
    // =====================================================================
    // IF/ID
    reg [31:0] instrD, pcplus4D;
    // ID/EX (control)
    reg        regwriteE, memtoregE, memwriteE, alusrcE, regdstE;
    reg [3:0]  alucontrolE;
    // ID/EX (data)
    reg [31:0] rd1E, rd2E, signimmE;
    reg [4:0]  rsE, rtE, rdE;
    // EX/MEM
    reg        regwriteM, memtoregM, memwriteM_r;
    reg [31:0] aluoutM_r, writedataM_r;
    reg [4:0]  writeregM;
    // MEM/WB
    reg        regwriteW, memtoregW;
    reg [31:0] aluoutW, readdataW;
    reg [4:0]  writeregW;

    assign memwriteM  = memwriteM_r;
    assign aluoutM    = aluoutM_r;
    assign writedataM = writedataM_r;

    // =====================================================================
    //  DECODE (ID)
    // =====================================================================
    wire [5:0] opD    = instrD[31:26];
    wire [5:0] functD = instrD[5:0];
    wire [4:0] rsD    = instrD[25:21];
    wire [4:0] rtD    = instrD[20:16];
    wire [4:0] rdD    = instrD[15:11];
    wire [31:0] signimmD = {{16{instrD[15]}}, instrD[15:0]};

    // control unit
    wire regwriteD, regdstD, alusrcD, branchD, bneD, memwriteD, memtoregD, jumpD;
    wire [3:0] alucontrolD;
    controller ctrl (
        .op(opD), .funct(functD),
        .regwrite(regwriteD), .regdst(regdstD), .alusrc(alusrcD),
        .branch(branchD), .bne(bneD), .memwrite(memwriteD),
        .memtoreg(memtoregD), .jump(jumpD), .alucontrol(alucontrolD)
    );

    // register file (read in ID, write in WB)
    wire [31:0] rd1D, rd2D, resultW;
    regfile rf (
        .clk(clk), .we3(regwriteW),
        .ra1(rsD), .ra2(rtD), .wa3(writeregW), .wd3(resultW),
        .rd1(rd1D), .rd2(rd2D)
    );

    // hazard / forwarding signals
    wire [1:0] forwardAE, forwardBE;
    wire       forwardAD, forwardBD;
    wire       stallF, stallD, flushE;

    // early branch comparator (with forwarding from MEM-stage ALU result)
    wire [31:0] cmpaD = forwardAD ? aluoutM_r : rd1D;
    wire [31:0] cmpbD = forwardBD ? aluoutM_r : rd2D;
    wire        equalD     = (cmpaD == cmpbD);
    wire        branchcondD = bneD ? ~equalD : equalD;
    wire        takebranchD = branchD & branchcondD & ~stallD;
    wire        takejumpD   = jumpD & ~stallD;

    // branch / jump targets
    wire [31:0] pcbranchD = pcplus4D + {signimmD[29:0], 2'b00};
    wire [31:0] pcjumpD   = {pcplus4D[31:28], instrD[25:0], 2'b00};

    // next-PC select
    assign pcnextF = takejumpD   ? pcjumpD :
                     takebranchD ? pcbranchD :
                                   pcplus4F;

    // =====================================================================
    //  EXECUTE (EX)
    // =====================================================================
    // forwarding muxes
    wire [31:0] srcaE =
        (forwardAE == 2'b10) ? aluoutM_r :
        (forwardAE == 2'b01) ? resultW   : rd1E;
    wire [31:0] srcb_preE =
        (forwardBE == 2'b10) ? aluoutM_r :
        (forwardBE == 2'b01) ? resultW   : rd2E;
    wire [31:0] srcbE = alusrcE ? signimmE : srcb_preE;

    wire [31:0] aluresultE;
    wire        zeroE;
    alu alu_u (.a(srcaE), .b(srcbE), .alucontrol(alucontrolE),
               .result(aluresultE), .zero(zeroE));

    wire [4:0]  writeregE = regdstE ? rdE : rtE;

    // =====================================================================
    //  hazard unit
    // =====================================================================
    hazard hz (
        .rsD(rsD), .rtD(rtD), .rsE(rsE), .rtE(rtE),
        .writeregE(writeregE), .writeregM(writeregM), .writeregW(writeregW),
        .regwriteE(regwriteE), .regwriteM(regwriteM), .regwriteW(regwriteW),
        .memtoregE(memtoregE), .memtoregM(memtoregM), .branchD(branchD),
        .forwardAE(forwardAE), .forwardBE(forwardBE),
        .forwardAD(forwardAD), .forwardBD(forwardBD),
        .stallF(stallF), .stallD(stallD), .flushE(flushE)
    );

    // =====================================================================
    //  WRITE BACK (WB)
    // =====================================================================
    assign resultW = memtoregW ? readdataW : aluoutW;

    // =====================================================================
    //  sequential logic (all pipeline registers)
    // =====================================================================
    // ---- PC ----
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)        pcF_r <= 32'd0;
        else if (~stallF)  pcF_r <= pcnextF;
    end

    // ---- IF/ID ----
    // flush (NOP) when a branch/jump is taken; hold when stalled; else load.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            instrD <= 32'd0; pcplus4D <= 32'd0;
        end else if (~stallD) begin
            if (takebranchD | takejumpD) begin
                instrD <= 32'd0;            // squash wrong-path instruction
                pcplus4D <= 32'd0;
            end else begin
                instrD <= instrF;
                pcplus4D <= pcplus4F;
            end
        end
        // else: stall -> hold
    end

    // ---- ID/EX ----  (flushE injects a bubble)
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n || flushE) begin
            regwriteE <= 1'b0; memtoregE <= 1'b0; memwriteE <= 1'b0;
            alusrcE <= 1'b0; regdstE <= 1'b0; alucontrolE <= 4'b0;
            rd1E <= 32'd0; rd2E <= 32'd0; signimmE <= 32'd0;
            rsE <= 5'd0; rtE <= 5'd0; rdE <= 5'd0;
        end else begin
            regwriteE <= regwriteD; memtoregE <= memtoregD; memwriteE <= memwriteD;
            alusrcE <= alusrcD; regdstE <= regdstD; alucontrolE <= alucontrolD;
            rd1E <= rd1D; rd2E <= rd2D; signimmE <= signimmD;
            rsE <= rsD; rtE <= rtD; rdE <= rdD;
        end
    end

    // ---- EX/MEM ----
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            regwriteM <= 1'b0; memtoregM <= 1'b0; memwriteM_r <= 1'b0;
            aluoutM_r <= 32'd0; writedataM_r <= 32'd0; writeregM <= 5'd0;
        end else begin
            regwriteM <= regwriteE; memtoregM <= memtoregE; memwriteM_r <= memwriteE;
            aluoutM_r <= aluresultE; writedataM_r <= srcb_preE; writeregM <= writeregE;
        end
    end

    // ---- MEM/WB ----
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            regwriteW <= 1'b0; memtoregW <= 1'b0;
            aluoutW <= 32'd0; readdataW <= 32'd0; writeregW <= 5'd0;
        end else begin
            regwriteW <= regwriteM; memtoregW <= memtoregM;
            aluoutW <= aluoutM_r; readdataW <= readdataM; writeregW <= writeregM;
        end
    end

endmodule
