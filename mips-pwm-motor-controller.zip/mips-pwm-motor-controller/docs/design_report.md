# Design Report — MIPS PWM Motor Controller

## 1. Introduction

This project builds a complete embedded system in Verilog: a 5-stage pipelined MIPS processor that controls a motor's speed by driving a PWM signal through Memory-Mapped I/O. Software running on the CPU writes an 8-bit duty value to a hardware PWM peripheral, which converts it into a square wave whose average power drives a motor. It matters because it is the canonical pattern of real embedded control — ordinary load/store instructions, not special I/O opcodes, reach the hardware, and a software algorithm shapes a physical actuator's behaviour over time.

## 2. System architecture

```
 switches[7:0] ─► data_memory(0x90) ─► CPU ─► data_memory(0x98/0x9C) ─► pwm_controller ─► pwm_out
                                       ▲
                  instr_memory ──► datapath ◄── readdataM
                                   │  │  │
                          controller alu regfile / hazard
```

| Module             | One-sentence job |
|--------------------|------------------|
| `mips.v`           | Top level; wires instruction memory, datapath, data memory and the PWM block together and exposes `switches`/`pwm_out`. |
| `datapath.v`       | The 5-stage (IF/ID/EX/MEM/WB) pipeline with all pipeline registers, forwarding muxes and early branch resolution. |
| `controller.v`     | Decodes the opcode into control signals (main decoder) and the ALU operation (ALU decoder). |
| `alu.v`            | Computes AND/OR/ADD/SUB/SLT for the EX stage. |
| `regfile.v`        | 32×32 register file: two combinational reads, one negedge-clocked write (read-after-write within a cycle). |
| `hazard.v`         | Detects data/branch/load-use hazards and produces forwarding selects, stalls and flushes. |
| `data_memory.v`    | Unified RAM + MMIO address decoder; holds the PWM duty and enable registers. |
| `pwm_controller.v` | Free-running counter + comparator that turns the 8-bit duty into a square wave. |

The three hazard mechanisms required of a correct pipeline are all present: **early branch resolution** in ID (1-cycle penalty), **data forwarding** from the MEM and WB pipeline registers into the ALU and into the ID branch comparator, and a **load-use stall** that inserts one bubble when an instruction needs a value still being loaded.

## 3. MMIO design

The address map (identical to the README):

| Address  | Device     | Direction  |
|----------|------------|------------|
| `0x0090` | switches   | read-only  |
| `0x0098` | PWM duty   | write-only |
| `0x009C` | PWM enable | write-only |
| other    | RAM        | read/write |

`data_memory.v` decodes the byte address coming out of the EX stage in a `case` statement. A write (`we=1`) to `0x98` latches the low 8 bits into the `pwm_duty` register; a write to `0x9C` latches bit 0 into `pwm_en`; everything else writes ordinary RAM. A read of `0x90` returns the zero-extended `switches` pins; everything else returns RAM.

**Writes are synchronous** (registered on the clock edge) because the duty/enable registers are state that must hold its value between writes and update deterministically on one edge — exactly what a flip-flop provides, and it matches how a real peripheral register behaves. **Reads are combinational** so that a `lw` obtains its data within the same MEM stage it executes in; registering the read would add a cycle of latency and break the single-cycle-memory assumption the pipeline is built around.

## 4. PWM controller design

The peripheral is the textbook **counter + comparator**:

* An 8-bit counter increments every clock while `en=1`, wrapping `255 → 0`. One full sweep is therefore the PWM period.
* The comparator drives `pwm_out = en & (counter < duty)`. The output is high for exactly `duty` of the 256 counts, so the high-time fraction equals `duty / 256` — the duty cycle.

Mapping duty to the waveform: `duty = 0` gives a permanently-low output (0 % power, motor off); `duty = 128` gives ≈ 50 %; `duty = 255` gives high for 255/256 of the period (≈ 100 %). The 8-bit resolution gives 256 distinct power levels.

**Frequency:** the counter needs 256 clock ticks for one period, so

```
T_pwm = 256 × T_clk
f_pwm = f_clk / 256
```

At the testbench's 100 MHz clock (`T_clk = 10 ns`), `T_pwm = 2.56 µs`, i.e. `f_pwm ≈ 390.6 kHz`. (A real motor driver would use a much slower clock or a prescaler; the ratio is what matters here.)

## 5. Software algorithm

**Profile chosen: Option A — ramp-up → hold-max → ramp-down → hold-zero, repeating.** It was chosen because it is self-contained (it needs no external switch stimulus to be interesting), and it exercises arithmetic, signed comparison, conditional branches, an inner delay loop and an unconditional jump — a good workout for the forwarding and hazard logic.

Pseudocode:

```
enable_pwm()                       # sw 1 -> 0x9C
loop forever:
    duty = 0
    while duty < 256:              # ramp up
        write duty -> 0x98
        delay(DELAY)
        duty += 8
    write 255 -> 0x98 ; delay(HOLD)   # hold max
    duty = 255
    while duty >= 0:               # ramp down
        write duty -> 0x98
        delay(DELAY)
        duty -= 8
    write 0 -> 0x98 ; delay(HOLD)     # hold zero
```

`delay(N)` is a tight count-up loop: `addi $t3,$t3,1 ; bne $t3,$t4,loop`. Its purpose is to hold each duty value long enough for the PWM output to complete one or more full 256-clock periods, so the changing pulse-width is visible. With `DELAY = 100` iterations and each iteration costing roughly 3–4 clocks (the `bne` depends on the immediately-preceding `addi`, so the hazard unit inserts one branch-stall, and the taken branch adds the 1-cycle penalty), one duty step is held for ≈ 300–400 clocks — comfortably longer than one 256-clock PWM period. Raising `DELAY` slows the ramp; lowering it speeds the motor profile up. The signed `slti` against `256` (ramp up) and against `0` (ramp down) is what makes each `while` terminate at the right boundary.

## 6. Reflection

**Harder than expected:** getting the *early branch in ID* to interact correctly with forwarding and stalls. A branch whose operand is still being computed in EX cannot be forwarded from the MEM stage yet, so the hazard unit has to *stall* the branch for a cycle rather than forward — and that branch-stall has to dominate the IF/ID flush logic, otherwise the branch instruction itself gets squashed. Ordering "stall holds, flush only when not stalled" was the subtle fix.

**What I would change with more time:** add a hardware prescaler register to the PWM block so the period can be set in software (decoupling motor frequency from the CPU clock), and write a proper assembler/loader instead of hand-checking the hex. I would also add an Option-B switch-controlled mode behind a compile-time flag so the same hardware demonstrates both an autonomous profile and live operator control.
