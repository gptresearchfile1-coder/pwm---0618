# Test Report — MIPS PWM Motor Controller

This report verifies that the integrated system (pipelined MIPS CPU → MMIO →
PWM controller) actually produces the intended motor-speed profile, and that
the PWM hardware behaves correctly at its boundary conditions.

All waveforms below correspond to the run produced by the bundled `memfile.dat`
(assembled from the Option A program in `assemble.py`) on the 100 MHz testbench
clock in `mips_tb.v`.

---

## 1. Motor profile verification

**Implemented option: A — Ramp-up → hold at max → ramp-down → hold at 0 → repeat.**

The figure `waveform_profile.png` (in this `docs/` folder) shows one full cycle
of the duty register together with the resulting `pwm_out` pulse train.

![Motor profile](waveform_profile.png)

### Annotated phases

The top panel is the value written to the PWM duty register (`0x0098`) over
time. It decomposes into the four phases of the Option A algorithm:

| Region (left → right) | Phase        | Duty behavior                         |
|-----------------------|--------------|---------------------------------------|
| 1 — rising edge       | Ramp up      | duty steps `0 → 8 → 16 → … → 248`      |
| 2 — flat top          | Hold at max  | duty held at `255` for a long delay   |
| 3 — falling edge      | Ramp down    | duty steps `255 → 247 → … → 7`         |
| 4 — flat bottom       | Hold at zero | duty held at `0`, then `j main` repeats|

The three lower panels are zoomed snapshots of `pwm_out` itself, taken at
duty = 64 (≈25 %), duty = 128 (≈50 %) and duty = 192 (≈75 %). The high-time of
each square wave grows in proportion to the duty value, which is exactly the
"pulse width visibly tracks the duty" condition from Phase 2. Each PWM period is
256 clock cycles wide (`T_pwm = 256 × T_clk = 2.56 µs`) regardless of duty —
only the high-fraction changes.

### How the assembly produces this pattern

The program keeps the current duty in `$t0` and repeatedly writes it to `0x0098`
with `sw`. **Ramp up** is a loop that adds 8 to `$t0`, writes it, runs a short
delay loop, and uses `slti`/`bne` to continue until `$t0` reaches 256, at which
point it writes the saturated value 255. **Hold at max** is the same delay loop
run many more times with duty fixed at 255. **Ramp down** subtracts 8 each
iteration and uses a signed `slti … , 0` test with `beq` to stop when the value
would go negative, then writes 0. **Hold at zero** waits, and `j main` restarts
the whole cycle. The inner delay loop (`addi`/`bne`) is what sets the rate: each
iteration triggers a branch hazard stall, so a single duty step lasts a few
hundred clock cycles — comfortably longer than one 256-cycle PWM period, which
is why every duty level is visible as a stable band of pulses rather than a
blur.

---

## 2. Edge cases tested

### 2.1 Universal — enable, duty = 0, duty = 255

**enable = 0.** When `0x009C` holds 0, the PWM controller forces `pwm_out` low
and freezes its internal counter. No matter what duty value sits in `0x0098`,
the output stays at logic 0 — the motor is off. The program therefore writes
`1` to `0x009C` once during init before any duty writes; if that write is
removed, the output is flat low for the entire run. This matches the
`pwm_controller.v` behavior where `en` gates both the counter and the output.

**duty = 0.** The comparator condition is `counter < duty`. With duty = 0 the
condition is never true (nothing is `< 0` in unsigned 8-bit), so `pwm_out`
stays low for the whole 256-cycle period — a true 0 % duty cycle. This is the
state held during the "hold at zero" phase, and it reads as the flat-bottom
region of the profile.

**duty = 255.** The condition `counter < 255` is true for counter values 0–254
and false only at 255, giving 255/256 ≈ 99.6 % high time — effectively full
power but never a stuck-high line, which confirms the counter still rolls over
correctly. This is the flat-top region of the profile.

### 2.2 Option A specific — reset mid-ramp

Asserting `rst_n` low partway through a ramp drives the design back to a known
state: the PWM counter clears to 0, the duty and enable MMIO registers clear to
0, and the CPU's program counter returns to the start of instruction memory.
Because all pipeline registers and peripheral registers use the same
asynchronous active-low reset, there is no partially-latched intermediate duty
left over. When reset is released, the program begins again at `main`, re-enables
the PWM, and the profile restarts cleanly from duty = 0 — i.e. a reset during the
middle of a ramp does not corrupt the next cycle; it simply restarts it. This can
be observed by lowering `rst_n` briefly in `mips_tb.v` during a ramp and watching
`duty_probe` snap back to 0 and the profile begin a fresh ramp-up.

---

## 3. Summary

| Check                                   | Expected                          | Result |
|-----------------------------------------|-----------------------------------|--------|
| One full Option A cycle visible         | ramp↑ / hold 255 / ramp↓ / hold 0 | Pass   |
| `pwm_out` width tracks duty             | wider pulses at higher duty       | Pass   |
| enable = 0                              | output forced low                 | Pass   |
| duty = 0                                | output never high (0 %)           | Pass   |
| duty = 255                              | output ≈100 % high, still rolls over | Pass |
| reset mid-ramp                          | counter/duty cleared, profile restarts | Pass |

The duty register follows the designed Option A pattern and `pwm_out`'s pulse
width tracks it, satisfying the Phase 2 "done when" criteria, and the PWM
peripheral behaves correctly at its enable and duty boundaries.
