// ============================================================================
//  hazard.v
//  Hazard-detection + forwarding unit (Harris & Harris pipelined MIPS style).
//
//  Handles three classes of hazard:
//    1. Data hazards (EX stage)  -> forward from MEM/WB into ALU inputs.
//    2. Data hazards for early-resolved branches (ID stage)
//         -> forward MEM-stage ALU result into the equality comparator,
//            OR stall when the needed value is not ready yet.
//    3. Load-use hazard -> insert one bubble (stall IF/ID, flush EX).
// ============================================================================
module hazard (
    // ---- register specifiers ----
    input  wire [4:0] rsD, rtD,        // decode-stage sources (also branch ops)
    input  wire [4:0] rsE, rtE,        // execute-stage sources
    input  wire [4:0] writeregE,       // EX  destination
    input  wire [4:0] writeregM,       // MEM destination
    input  wire [4:0] writeregW,       // WB  destination
    // ---- control bits ----
    input  wire       regwriteE,
    input  wire       regwriteM,
    input  wire       regwriteW,
    input  wire       memtoregE,       // EX  stage is a load
    input  wire       memtoregM,       // MEM stage is a load
    input  wire       branchD,         // a branch sits in decode
    // ---- forwarding selects ----
    output reg  [1:0] forwardAE,       // 00=RF 10=MEM 01=WB
    output reg  [1:0] forwardBE,
    output wire       forwardAD,       // forward MEM result to branch cmp (a)
    output wire       forwardBD,       // forward MEM result to branch cmp (b)
    // ---- stall / flush ----
    output wire       stallF,
    output wire       stallD,
    output wire       flushE
);

    // ---- forwarding to the EX-stage ALU ---------------------------------
    always @(*) begin
        // operand A
        if      ((rsE != 5'b0) && (rsE == writeregM) && regwriteM) forwardAE = 2'b10;
        else if ((rsE != 5'b0) && (rsE == writeregW) && regwriteW) forwardAE = 2'b01;
        else                                                       forwardAE = 2'b00;
        // operand B
        if      ((rtE != 5'b0) && (rtE == writeregM) && regwriteM) forwardBE = 2'b10;
        else if ((rtE != 5'b0) && (rtE == writeregW) && regwriteW) forwardBE = 2'b01;
        else                                                       forwardBE = 2'b00;
    end

    // ---- forwarding to the ID-stage branch comparator -------------------
    assign forwardAD = (rsD != 5'b0) && (rsD == writeregM) && regwriteM;
    assign forwardBD = (rtD != 5'b0) && (rtD == writeregM) && regwriteM;

    // ---- load-use stall -------------------------------------------------
    wire lwstall = ((rsD == rtE) || (rtD == rtE)) && memtoregE;

    // ---- branch stall (branch needs a value still being produced) -------
    wire branchstall =
        (branchD && regwriteE && ((writeregE == rsD) || (writeregE == rtD))) ||
        (branchD && memtoregM && ((writeregM == rsD) || (writeregM == rtD)));

    assign stallD = lwstall || branchstall;
    assign stallF = lwstall || branchstall;
    assign flushE = lwstall || branchstall;

endmodule
