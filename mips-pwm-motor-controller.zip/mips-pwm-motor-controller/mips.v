// ============================================================================
//  mips.v
//  Top-level CPU.  Wires together:
//     instruction memory (ROM)  +  pipelined datapath  +  data memory (MMIO)
//     +  PWM peripheral.
//
//  External ports (the whole point of the project):
//     switches[7:0] : 8-bit input pins   (read by software at MMIO 0x90)
//     pwm_out       : PWM square wave out (driven by software via 0x98/0x9C)
// ============================================================================
module mips (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] switches,
    output wire       pwm_out
);

    // ---- inter-module wiring --------------------------------------------
    wire [31:0] pcF, instrF;
    wire [31:0] aluoutM, writedataM, readdataM;
    wire        memwriteM;
    wire [7:0]  pwm_duty;
    wire        pwm_en;

    // ---- instruction memory (word-addressed ROM) ------------------------
    reg [31:0] imem [0:255];
    initial $readmemh("memfile.dat", imem);
    assign instrF = imem[pcF[9:2]];   // PC is a byte address; /4 -> word index

    // ---- pipelined datapath ---------------------------------------------
    datapath dp (
        .clk(clk), .rst_n(rst_n),
        .instrF(instrF), .readdataM(readdataM),
        .pcF(pcF), .memwriteM(memwriteM),
        .aluoutM(aluoutM), .writedataM(writedataM)
    );

    // ---- data memory + MMIO ---------------------------------------------
    data_memory dmem (
        .clk(clk), .rst_n(rst_n), .we(memwriteM),
        .a(aluoutM), .wd(writedataM), .switches(switches),
        .rd(readdataM), .pwm_duty(pwm_duty), .pwm_en(pwm_en)
    );

    // ---- PWM peripheral --------------------------------------------------
    pwm_controller pwm (
        .clk(clk), .rst_n(rst_n),
        .en(pwm_en), .duty(pwm_duty), .pwm_out(pwm_out)
    );

endmodule
