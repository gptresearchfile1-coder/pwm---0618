// ============================================================================
//  mips_tb.v
//  Testbench for the MIPS PWM motor controller.
//
//    * Generates a 100 MHz clock (10 ns period).
//    * Applies an active-low reset for a few cycles.
//    * Drives the 8-bit `switches` input (unused by Option A, but provided so
//      the same bench can exercise Option B — see the SWITCH demo block).
//    * Dumps wave.vcd for GTKWave and prints every change of the duty register.
// ============================================================================
`timescale 1ns/1ps

module mips_tb;

    reg        clk;
    reg        rst_n;
    reg  [7:0] switches;
    wire       pwm_out;

    // ---- device under test ----------------------------------------------
    mips dut (
        .clk(clk), .rst_n(rst_n),
        .switches(switches), .pwm_out(pwm_out)
    );

    // convenient probes into the design (for GTKWave / $monitor)
    wire [7:0] duty_probe    = dut.dmem.pwm_duty;
    wire       en_probe      = dut.dmem.pwm_en;
    wire [7:0] counter_probe = dut.pwm.counter;

    // ---- clock : 10 ns period -------------------------------------------
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // ---- reset + stimulus ------------------------------------------------
    initial begin
        rst_n    = 1'b0;
        switches = 8'h00;
        repeat (4) @(posedge clk);   // hold reset 4 cycles
        rst_n = 1'b1;

        // ---- SWITCH demo (relevant only for Option B) -------------------
        // For Option A the program never reads 0x90, so these are inert.
        // Uncomment / adapt for an Option-B "switch-controlled duty" test:
        // #20000  switches = 8'h40;   // 25%
        // #20000  switches = 8'h80;   // 50%
        // #20000  switches = 8'hC0;   // 75%
        switches = 8'h55;             // arbitrary steady value
    end

    // ---- report duty changes on the console -----------------------------
    reg [7:0] last_duty;
    initial last_duty = 8'hxx;
    always @(posedge clk) begin
        if (en_probe && duty_probe !== last_duty) begin
            $display("t=%8t ns : duty = %3d  (%0d%%)  en=%b",
                     $time, duty_probe, (duty_probe*100)/255, en_probe);
            last_duty <= duty_probe;
        end
    end

    // ---- waveform dump + run length -------------------------------------
    initial begin
        $dumpfile("wave.vcd");
        $dumpvars(0, mips_tb);     // dump everything (DUT internals included)
        // Run long enough to see at least one full ramp-up/hold/down/hold cycle.
        #700000;                   // 700 us = 70,000 clock cycles
        $display("=== simulation finished at t=%0t ns ===", $time);
        $finish;
    end

endmodule
