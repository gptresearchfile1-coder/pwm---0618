#!/usr/bin/env python3
"""Generate docs/waveform_profile.png from the reference-model trace."""
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

with open('trace.json') as f:
    data = json.load(f)
events = data['events']               # (cycle, duty)

# ---- top: duty profile (the motor-speed profile) --------------------------
# Build a step plot of duty vs event index (one point per sw to 0x98).
xs = list(range(len(events)))
ys = [d for _, d in events]
# keep a bit over one full profile for clarity
N = 0
# find end of first full cycle: up, hold, down, hold, then duty returns to ramp
# (just show first ~140 events which covers ~2 cycles)
show = min(len(events), 150)
xs, ys = xs[:show], ys[:show]

fig = plt.figure(figsize=(11, 8))
fig.suptitle("Option A  ·  Ramp-up → Hold-max → Ramp-down → Hold-zero (repeat)",
             fontsize=14, fontweight='bold')

ax1 = fig.add_axes([0.08, 0.55, 0.86, 0.34])
ax1.step(xs, ys, where='post', color='#1565c0', linewidth=1.8)
ax1.fill_between(xs, ys, step='post', alpha=0.12, color='#1565c0')
ax1.set_ylabel("PWM duty register (0–255)")
ax1.set_xlabel("duty update # (each = one sw to 0x98, ≈ one delay window)")
ax1.set_ylim(-10, 270)
ax1.set_title("Motor-speed profile: the duty register written by the MIPS program",
              fontsize=11)
ax1.grid(True, alpha=0.3)
# annotate phases on the first cycle
ax1.axhline(255, ls='--', color='gray', alpha=0.5)
ax1.text(15, 200, "ramp up", color='#1565c0', fontsize=10, rotation=38)
ax1.text(36, 258, "hold max (255)", color='#c62828', fontsize=10)
ax1.text(55, 130, "ramp down", color='#1565c0', fontsize=10, rotation=-38)
ax1.text(70, 8, "hold 0", color='#2e7d32', fontsize=10)

# ---- bottom: pwm_out pulse-width at three duties --------------------------
def pwm_wave(duty, periods=2):
    """counter 0..255 each period; high while counter<duty."""
    t, y = [], []
    for p in range(periods):
        for c in range(256):
            t.append(p*256 + c)
            y.append(1 if c < duty else 0)
    return t, y

panels = [(64, "25 %  (duty=64)", '#2e7d32'),
          (128, "50 %  (duty=128)", '#ef6c00'),
          (192, "75 %  (duty=192)", '#c62828')]
for i, (duty, label, col) in enumerate(panels):
    ax = fig.add_axes([0.08 + i*0.30, 0.08, 0.26, 0.32])
    t, y = pwm_wave(duty)
    ax.step(t, y, where='post', color=col, linewidth=1.5)
    ax.fill_between(t, y, step='post', alpha=0.25, color=col)
    ax.set_title(label, fontsize=10)
    ax.set_ylim(-0.2, 1.3)
    ax.set_yticks([0, 1])
    ax.set_xlabel("counter (period = 256·T_clk)")
    if i == 0:
        ax.set_ylabel("pwm_out")
    ax.grid(True, alpha=0.3)

fig.text(0.5, 0.46,
         "pwm_out high-time tracks the duty register  →  average power to the motor",
         ha='center', fontsize=10, style='italic', color='#555')

fig.savefig('docs/waveform_profile.png', dpi=110)
print("wrote docs/waveform_profile.png")
