// ============================================================================
//  pwm_controller.v
//  8-bit Pulse-Width-Modulation peripheral.
//
//    * A free-running counter cycles 0 -> 255 -> 0 ... (period = 256 * T_clk).
//    * pwm_out is HIGH while (counter < duty), LOW otherwise.
//      => high-time / period  ==  duty / 256   (the duty cycle).
//    * en = 0 forces the output low and freezes the counter at 0.
//
//  Interface required by the PBL spec:
//      clk, rst_n, en, duty[7:0]  -> pwm_out
// ============================================================================
module pwm_controller (
    input  wire       clk,      // system clock
    input  wire       rst_n,    // active-low reset
    input  wire       en,       // 1 = run, 0 = output forced low
    input  wire [7:0] duty,     // 8-bit duty value (0..255)
    output wire       pwm_out   // square wave
);

    reg [7:0] counter;

    // ---- free-running counter -------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            counter <= 8'd0;
        else if (en)
            counter <= counter + 8'd1;   // wraps 255 -> 0 automatically
        else
            counter <= 8'd0;             // held at 0 while disabled
    end

    // ---- comparator ------------------------------------------------------
    // duty = 0   -> output never high (0% power)
    // duty = 255 -> high for 255/256 of the period (almost 100%)
    assign pwm_out = en & (counter < duty);

endmodule
