// ============================================================================
//  regfile.v
//  32 x 32-bit MIPS register file.
//     * Two combinational (asynchronous) read ports.
//     * One synchronous write port, writing on the NEGATIVE clock edge so the
//       value written in WB is already visible to a read in ID of the same
//       cycle (the classic "write first half / read second half" trick used
//       in the Harris & Harris pipelined MIPS).
//     * Register $0 is hard-wired to 0.
// ============================================================================
module regfile (
    input  wire        clk,
    input  wire        we3,        // write enable (regwrite, WB stage)
    input  wire [4:0]  ra1, ra2,   // read addresses (ID stage)
    input  wire [4:0]  wa3,        // write address (WB stage)
    input  wire [31:0] wd3,        // write data (WB stage)
    output wire [31:0] rd1, rd2
);

    reg [31:0] rf [0:31];

    always @(negedge clk) begin
        if (we3) rf[wa3] <= wd3;
    end

    assign rd1 = (ra1 == 5'b0) ? 32'b0 : rf[ra1];
    assign rd2 = (ra2 == 5'b0) ? 32'b0 : rf[ra2];

endmodule
