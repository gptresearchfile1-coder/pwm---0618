//==============================================================================
// 5-Stage MIPS Pipelined Datapath
// Stages: IF (Fetch), ID (Decode), EX (Execute), MEM (Memory), WB (Writeback)
// Includes Pipeline Registers and Hazard/Forwarding support.
//
// MODIFIED:
// 1. Early Branch Resolution supports BNE opcode 000101.
// 2. reg_write_E is exported to hazard_unit for branch operand stall.
//==============================================================================

`timescale 1ns / 1ps

module datapath (
    input  wire        clk,
    input  wire        rst_n,
    
    // Control signals from Decode stage
    input  wire        reg_write_D,
    input  wire        mem_to_reg_D,
    input  wire        mem_write_D,
    input  wire [2:0]  alu_ctrl_D,
    input  wire        alu_src_D,
    input  wire        reg_dst_D,
    input  wire        branch_D,
    
    // Forwarding / hazard control inputs
    input  wire [1:0]  forward_a_E,
    input  wire [1:0]  forward_b_E,
    input  wire [1:0]  forward_a_D,
    input  wire [1:0]  forward_b_D,
    input  wire        stall_F,
    input  wire        stall_D,
    input  wire        flush_E,
    
    // Feedback outputs to hazard unit
    output wire [4:0]  rs_D,
    output wire [4:0]  rt_D,
    output wire [4:0]  rs_E,
    output wire [4:0]  rt_E,
    output wire [4:0]  write_reg_E,
    output wire        reg_write_E,     // ADDED
    output wire        mem_to_reg_E,
    output wire [4:0]  write_reg_M,
    output wire        reg_write_M,
    output wire [4:0]  write_reg_W,
    output wire        reg_write_W,
    
    // Debug outputs
    output wire [31:0] instr_out_D,
    output wire [31:0] pc_out,
    output wire [31:0] alu_result_out
);

    //--------------------------------------------------------------------------
    // STAGE 1: FETCH
    //--------------------------------------------------------------------------

    wire [31:0] pc_F;
    wire [31:0] pc_next_F;
    wire [31:0] pc_plus4_F;
    wire [31:0] instr_F;

    wire        pc_src_D;
    wire [31:0] pc_branch_D;
    
    pc u_pc (
        .clk(clk),
        .rst_n(rst_n),
        .en(!stall_F),
        .pc_next(pc_next_F),
        .pc(pc_F)
    );
    
    instruction_memory u_imem (
        .addr(pc_F),
        .rd(instr_F)
    );
    
    assign pc_plus4_F = pc_F + 32'd4;
    assign pc_next_F  = (pc_src_D) ? pc_branch_D : pc_plus4_F;
    assign pc_out     = pc_F;

    //--------------------------------------------------------------------------
    // IF/ID Pipeline Register
    //--------------------------------------------------------------------------

    reg [31:0] instr_D_reg;
    reg [31:0] pc_plus4_D;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            instr_D_reg <= 32'b0;
            pc_plus4_D  <= 32'b0;
        end
        else if (!stall_D) begin
            if (pc_src_D) begin
                // Branch taken: kill the instruction fetched after branch
                instr_D_reg <= 32'b0;
                pc_plus4_D  <= 32'b0;
            end
            else begin
                instr_D_reg <= instr_F;
                pc_plus4_D  <= pc_plus4_F;
            end
        end
    end

    assign instr_out_D = instr_D_reg;

    assign rs_D = instr_D_reg[25:21];
    assign rt_D = instr_D_reg[20:16];

    //--------------------------------------------------------------------------
    // STAGE 2: DECODE
    //--------------------------------------------------------------------------

    wire [31:0] rd1_D;
    wire [31:0] rd2_D;
    wire [31:0] sign_imm_D;
    wire [31:0] result_W;
    
    reg_file u_reg_file (
        .clk(~clk),
        .we3(reg_write_W),
        .ra1(rs_D),
        .ra2(rt_D),
        .wa3(write_reg_W),
        .wd3(result_W),
        .rd1(rd1_D),
        .rd2(rd2_D)
    );
    
    assign sign_imm_D = {{16{instr_D_reg[15]}}, instr_D_reg[15:0]};

    //--------------------------------------------------------------------------
    // Early Branch Resolution in Decode Stage
    //--------------------------------------------------------------------------

    wire [31:0] src_a_D;
    wire [31:0] src_b_D;

    wire [31:0] alu_result_M_wire;

    assign src_a_D = (forward_a_D == 2'b10) ? alu_result_M_wire :
                     (forward_a_D == 2'b01) ? result_W :
                                               rd1_D;

    assign src_b_D = (forward_b_D == 2'b10) ? alu_result_M_wire :
                     (forward_b_D == 2'b01) ? result_W :
                                               rd2_D;
    
    assign pc_branch_D = pc_plus4_D + (sign_imm_D << 2);

    // BNE opcode = 000101
    wire bne_D;
    wire equal_D;

    assign bne_D   = (instr_D_reg[31:26] == 6'b000101);
    assign equal_D = (src_a_D == src_b_D);

    // BEQ: branch when equal
    // BNE: branch when not equal
    assign pc_src_D = branch_D & (bne_D ? ~equal_D : equal_D);

    //--------------------------------------------------------------------------
    // ID/EX Pipeline Register
    //--------------------------------------------------------------------------

    reg        reg_write_E_reg;
    reg        mem_to_reg_E_reg;
    reg        mem_write_E;
    reg        alu_src_E;
    reg        reg_dst_E;

    reg [2:0]  alu_ctrl_E;

    reg [31:0] rd1_E;
    reg [31:0] rd2_E;
    reg [31:0] sign_imm_E;

    reg [4:0]  rs_E_reg;
    reg [4:0]  rt_E_reg;
    reg [4:0]  rd_E;
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n || flush_E) begin
            reg_write_E_reg <= 1'b0;
            mem_to_reg_E_reg <= 1'b0;
            mem_write_E <= 1'b0;
            alu_src_E <= 1'b0;
            reg_dst_E <= 1'b0;

            alu_ctrl_E <= 3'b000;

            rd1_E <= 32'b0;
            rd2_E <= 32'b0;
            sign_imm_E <= 32'b0;

            rs_E_reg <= 5'b0;
            rt_E_reg <= 5'b0;
            rd_E <= 5'b0;
        end
        else begin
            reg_write_E_reg <= reg_write_D;
            mem_to_reg_E_reg <= mem_to_reg_D;
            mem_write_E <= mem_write_D;
            alu_src_E <= alu_src_D;
            reg_dst_E <= reg_dst_D;

            alu_ctrl_E <= alu_ctrl_D;

            rd1_E <= rd1_D;
            rd2_E <= rd2_D;
            sign_imm_E <= sign_imm_D;

            rs_E_reg <= rs_D;
            rt_E_reg <= rt_D;
            rd_E <= instr_D_reg[15:11];
        end
    end

    assign rs_E         = rs_E_reg;
    assign rt_E         = rt_E_reg;
    assign mem_to_reg_E = mem_to_reg_E_reg;
    assign reg_write_E  = reg_write_E_reg;     // ADDED

    //--------------------------------------------------------------------------
    // STAGE 3: EXECUTE
    //--------------------------------------------------------------------------

    wire [31:0] src_a_E_final;
    wire [31:0] src_b_E_temp;
    wire [31:0] src_b_E_final;

    wire [31:0] alu_result_E;
    wire        zero_E;
    
    assign src_a_E_final = (forward_a_E == 2'b10) ? alu_result_M_wire :
                           (forward_a_E == 2'b01) ? result_W :
                                                     rd1_E;
                           
    assign src_b_E_temp  = (forward_b_E == 2'b10) ? alu_result_M_wire :
                           (forward_b_E == 2'b01) ? result_W :
                                                     rd2_E;
                           
    assign src_b_E_final = (alu_src_E) ? sign_imm_E : src_b_E_temp;
    
    assign write_reg_E = (reg_dst_E) ? rd_E : rt_E_reg;
    
    alu u_alu (
        .src_a(src_a_E_final),
        .src_b(src_b_E_final),
        .alu_ctrl(alu_ctrl_E),
        .result(alu_result_E),
        .zero(zero_E)
    );

    //--------------------------------------------------------------------------
    // EX/MEM Pipeline Register
    //--------------------------------------------------------------------------

    reg        reg_write_M_reg;
    reg        mem_to_reg_M;
    reg        mem_write_M;

    reg [31:0] alu_result_M_reg;
    reg [31:0] write_data_M;

    reg [4:0]  write_reg_M_reg;
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            reg_write_M_reg <= 1'b0;
            mem_to_reg_M <= 1'b0;
            mem_write_M <= 1'b0;

            alu_result_M_reg <= 32'b0;
            write_data_M <= 32'b0;

            write_reg_M_reg <= 5'b0;
        end
        else begin
            reg_write_M_reg <= reg_write_E_reg;
            mem_to_reg_M <= mem_to_reg_E_reg;
            mem_write_M <= mem_write_E;

            alu_result_M_reg <= alu_result_E;
            write_data_M <= src_b_E_temp;

            write_reg_M_reg <= write_reg_E;
        end
    end

    assign alu_result_M_wire = alu_result_M_reg;

    assign write_reg_M = write_reg_M_reg;
    assign reg_write_M = reg_write_M_reg;

    //--------------------------------------------------------------------------
    // STAGE 4: MEMORY
    //--------------------------------------------------------------------------

    wire [31:0] read_data_M;
    
    data_memory u_data_mem (
        .clk(clk),
        .mem_write_en(mem_write_M),
        .addr(alu_result_M_reg),
        .write_data(write_data_M),
        .read_data(read_data_M)
    );

    //--------------------------------------------------------------------------
    // MEM/WB Pipeline Register
    //--------------------------------------------------------------------------

    reg        reg_write_W_reg;
    reg        mem_to_reg_W;

    reg [31:0] read_data_W;
    reg [31:0] alu_result_W;

    reg [4:0]  write_reg_W_reg;
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            reg_write_W_reg <= 1'b0;
            mem_to_reg_W <= 1'b0;

            read_data_W <= 32'b0;
            alu_result_W <= 32'b0;

            write_reg_W_reg <= 5'b0;
        end
        else begin
            reg_write_W_reg <= reg_write_M_reg;
            mem_to_reg_W <= mem_to_reg_M;

            read_data_W <= read_data_M;
            alu_result_W <= alu_result_M_reg;

            write_reg_W_reg <= write_reg_M_reg;
        end
    end

    assign write_reg_W = write_reg_W_reg;
    assign reg_write_W = reg_write_W_reg;

    //--------------------------------------------------------------------------
    // STAGE 5: WRITEBACK
    //--------------------------------------------------------------------------

    assign result_W = (mem_to_reg_W) ? read_data_W : alu_result_W;
    
    assign alu_result_out = result_W;

endmodule