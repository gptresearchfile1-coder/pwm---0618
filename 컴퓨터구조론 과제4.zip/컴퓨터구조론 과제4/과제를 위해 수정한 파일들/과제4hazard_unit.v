//==============================================================================
// Hazard Unit: The Control "Brain" of the Pipelined Processor
// Responsibilities:
// 1. Data Forwarding to EX stage
// 2. Data Forwarding to ID stage for early branch comparison
// 3. Load-use stall
// 4. Branch operand stall for early branch resolution
//==============================================================================
`timescale 1ns / 1ps

module hazard_unit (
    // Data Hazard: EX stage operands
    input  wire [4:0] rs_E,
    input  wire [4:0] rt_E,

    // Destination register in EX stage
    input  wire [4:0] write_reg_E,
    input  wire       reg_write_E,

    // Destination registers in MEM/WB stages
    input  wire [4:0] write_reg_M,
    input  wire       reg_write_M,
    input  wire [4:0] write_reg_W,
    input  wire       reg_write_W,

    // ID stage operands
    input  wire [4:0] rs_D,
    input  wire [4:0] rt_D,

    // Load-use hazard
    input  wire [4:0] rt_E_load,
    input  wire       mem_to_reg_E,

    // Branch in Decode stage
    input  wire       branch_D,

    // Forwarding controls
    output reg  [1:0] forward_a_E,
    output reg  [1:0] forward_b_E,
    output reg  [1:0] forward_a_D,
    output reg  [1:0] forward_b_D,

    // Pipeline control
    output wire       stall_F,
    output wire       stall_D,
    output wire       flush_E
);

    //--------------------------------------------------------------------------
    // 1. Forwarding to EX Stage
    // 00 = register file
    // 10 = MEM stage result
    // 01 = WB stage result
    //--------------------------------------------------------------------------
    always @(*) begin
        if (reg_write_M && (write_reg_M != 5'b00000) && (write_reg_M == rs_E))
            forward_a_E = 2'b10;
        else if (reg_write_W && (write_reg_W != 5'b00000) && (write_reg_W == rs_E))
            forward_a_E = 2'b01;
        else
            forward_a_E = 2'b00;
    end

    always @(*) begin
        if (reg_write_M && (write_reg_M != 5'b00000) && (write_reg_M == rt_E))
            forward_b_E = 2'b10;
        else if (reg_write_W && (write_reg_W != 5'b00000) && (write_reg_W == rt_E))
            forward_b_E = 2'b01;
        else
            forward_b_E = 2'b00;
    end

    //--------------------------------------------------------------------------
    // 2. Forwarding to ID Stage for Early Branch Comparison
    //--------------------------------------------------------------------------
    always @(*) begin
        if (reg_write_M && (write_reg_M != 5'b00000) && (write_reg_M == rs_D))
            forward_a_D = 2'b10;
        else if (reg_write_W && (write_reg_W != 5'b00000) && (write_reg_W == rs_D))
            forward_a_D = 2'b01;
        else
            forward_a_D = 2'b00;
    end

    always @(*) begin
        if (reg_write_M && (write_reg_M != 5'b00000) && (write_reg_M == rt_D))
            forward_b_D = 2'b10;
        else if (reg_write_W && (write_reg_W != 5'b00000) && (write_reg_W == rt_D))
            forward_b_D = 2'b01;
        else
            forward_b_D = 2'b00;
    end

    //--------------------------------------------------------------------------
    // 3. Load-Use Stall
    //--------------------------------------------------------------------------
    wire lwstall;

    assign lwstall =
        mem_to_reg_E &&
        (rt_E_load != 5'b00000) &&
        ((rt_E_load == rs_D) || (rt_E_load == rt_D));

    //--------------------------------------------------------------------------
    // 4. Branch Operand Stall
    //
    // Example:
    //   addi $t1, $0, 5
    //   bne  $t0, $t1, -3
    //
    // When bne is in D stage, addi is still in E stage.
    // The branch comparator in D stage cannot yet use that result.
    // Therefore we stall one cycle.
    //--------------------------------------------------------------------------
    wire branchstall_E;

    assign branchstall_E =
        branch_D &&
        reg_write_E &&
        (write_reg_E != 5'b00000) &&
        ((write_reg_E == rs_D) || (write_reg_E == rt_D));

    //--------------------------------------------------------------------------
    // 5. Final Stall / Flush
    //--------------------------------------------------------------------------
    wire stall;

    assign stall = lwstall | branchstall_E;

    assign stall_F = stall;
    assign stall_D = stall;
    assign flush_E = stall;

endmodule