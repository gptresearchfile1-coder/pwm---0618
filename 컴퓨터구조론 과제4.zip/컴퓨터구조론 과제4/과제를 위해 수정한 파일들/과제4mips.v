//==============================================================================
// MIPS 5-Stage Pipelined Processor (Top-Level)
// This module connects the Datapath, Control Unit, and Hazard Unit.
//
// MODIFIED:
// 1. Connects reg_write_E from datapath to hazard_unit.
// 2. Connects write_reg_E to hazard_unit.
// 3. Connects branch_D to hazard_unit for early branch operand stall.
//==============================================================================

`timescale 1ns / 1ps

module mips (
    input  wire        clk,           // System Clock
    input  wire        rst_n,         // Active-Low Reset
    output wire [31:0] pc_out,        // Current Program Counter (for debug)
    output wire [31:0] alu_result     // Final result from WB stage (for debug)
);

    //--------------------------------------------------------------------------
    // 1. Internal Signals
    //--------------------------------------------------------------------------

    // Control signals from ID stage
    wire [31:0] instr_D;
    wire        reg_write_D;
    wire        mem_to_reg_D;
    wire        mem_write_D;
    wire        branch_D;
    wire        alu_src_D;
    wire        reg_dst_D;
    wire [2:0]  alu_ctrl_D;

    // Register numbers and destination registers
    wire [4:0] rs_D;
    wire [4:0] rt_D;
    wire [4:0] rs_E;
    wire [4:0] rt_E;

    wire [4:0] write_reg_E;
    wire [4:0] write_reg_M;
    wire [4:0] write_reg_W;

    // Register write enables
    wire reg_write_E;
    wire reg_write_M;
    wire reg_write_W;

    // Load-use information
    wire mem_to_reg_E;

    // Forwarding selectors
    // 00 = register file
    // 10 = MEM stage result
    // 01 = WB stage result
    wire [1:0] forward_a_E;
    wire [1:0] forward_b_E;
    wire [1:0] forward_a_D;
    wire [1:0] forward_b_D;

    // Pipeline control
    wire stall_F;
    wire stall_D;
    wire flush_E;

    //--------------------------------------------------------------------------
    // 2. Control Unit
    //--------------------------------------------------------------------------

    control_unit u_control (
        .opcode     (instr_D[31:26]),
        .funct      (instr_D[5:0]),

        .mem_to_reg (mem_to_reg_D),
        .mem_write  (mem_write_D),
        .branch     (branch_D),
        .alu_src    (alu_src_D),
        .reg_dst    (reg_dst_D),
        .reg_write  (reg_write_D),
        .alu_ctrl   (alu_ctrl_D)
    );

    //--------------------------------------------------------------------------
    // 3. Hazard Unit
    //--------------------------------------------------------------------------

    hazard_unit u_hazard (
        // EX stage source registers
        .rs_E         (rs_E),
        .rt_E         (rt_E),

        // EX stage destination information
        .write_reg_E  (write_reg_E),
        .reg_write_E  (reg_write_E),

        // MEM stage destination information
        .write_reg_M  (write_reg_M),
        .reg_write_M  (reg_write_M),

        // WB stage destination information
        .write_reg_W  (write_reg_W),
        .reg_write_W  (reg_write_W),

        // ID stage source registers
        .rs_D         (rs_D),
        .rt_D         (rt_D),

        // Load-use hazard information
        .rt_E_load    (rt_E),
        .mem_to_reg_E (mem_to_reg_E),

        // Branch information
        .branch_D     (branch_D),

        // Forwarding outputs to datapath
        .forward_a_E  (forward_a_E),
        .forward_b_E  (forward_b_E),
        .forward_a_D  (forward_a_D),
        .forward_b_D  (forward_b_D),

        // Stall / flush outputs to datapath
        .stall_F      (stall_F),
        .stall_D      (stall_D),
        .flush_E      (flush_E)
    );

    //--------------------------------------------------------------------------
    // 4. Datapath
    //--------------------------------------------------------------------------

    datapath u_datapath (
        .clk          (clk),
        .rst_n        (rst_n),

        // Control inputs from control unit
        .reg_write_D  (reg_write_D),
        .mem_to_reg_D (mem_to_reg_D),
        .mem_write_D  (mem_write_D),
        .alu_ctrl_D   (alu_ctrl_D),
        .alu_src_D    (alu_src_D),
        .reg_dst_D    (reg_dst_D),
        .branch_D     (branch_D),

        // Hazard / forwarding inputs from hazard unit
        .forward_a_E  (forward_a_E),
        .forward_b_E  (forward_b_E),
        .forward_a_D  (forward_a_D),
        .forward_b_D  (forward_b_D),
        .stall_F      (stall_F),
        .stall_D      (stall_D),
        .flush_E      (flush_E),

        // Feedback outputs to hazard unit
        .rs_D         (rs_D),
        .rt_D         (rt_D),
        .rs_E         (rs_E),
        .rt_E         (rt_E),

        .write_reg_E  (write_reg_E),
        .reg_write_E  (reg_write_E),
        .mem_to_reg_E (mem_to_reg_E),

        .write_reg_M  (write_reg_M),
        .reg_write_M  (reg_write_M),

        .write_reg_W  (write_reg_W),
        .reg_write_W  (reg_write_W),

        // Debug outputs
        .instr_out_D  (instr_D),
        .pc_out       (pc_out),
        .alu_result_out(alu_result)
    );

endmodule