`timescale 1ns / 1ps

module mips_tb;
    reg         clk;
    reg         rst_n;
    wire [31:0] pc_out;
    wire [31:0] alu_result;

    integer i;
    reg failed;

    mips uut (
        .clk(clk),
        .rst_n(rst_n),
        .pc_out(pc_out),
        .alu_result(alu_result)
    );

    // Clock generation: 10ns period
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Waveform dump
    initial begin
        $dumpfile("mips.vcd");
        $dumpvars(0, mips_tb);
    end

    initial begin
        failed = 0;

        // Reset
        rst_n = 0;

        // Initialize register file for clean simulation
        for (i = 0; i < 32; i = i + 1) begin
            uut.u_datapath.u_reg_file.rf[i] = 32'd0;
        end

        #10;
        rst_n = 1;

        $display("===========================================");
        $display("   MIPS 5-Stage Pipeline Simulation Start  ");
        $display("===========================================");
        $display("Check: $t2 must NEVER become 0x99 = 153");
        $display("");

        repeat (20) begin
            @(negedge clk);
            #1;

            $display("PC: 0x%h | ALU Result: %d | $t0=%d | $t1=%d | $t2=%d",
                     pc_out,
                     alu_result,
                     uut.u_datapath.u_reg_file.rf[8],
                     uut.u_datapath.u_reg_file.rf[9],
                     uut.u_datapath.u_reg_file.rf[10]);

            // $t2 = register 10
            if (uut.u_datapath.u_reg_file.rf[10] === 32'h00000099) begin
                failed = 1;
                $display("FAIL: $t2 became 0x99. Canary instruction executed.");
            end
        end

        $display("");
        $display("===========================================");
        if (failed)
            $display("RESULT: FAIL");
        else
            $display("RESULT: PASS - $t2 never reached 0x99");
        $display("===========================================");

        $finish;
    end

endmodule